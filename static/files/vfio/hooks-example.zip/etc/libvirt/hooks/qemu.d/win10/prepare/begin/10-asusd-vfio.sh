#!/bin/bash

## Load VM variables
source "/etc/libvirt/hooks/qemu.d/win10/vm-vars.conf"

## Use asusctl to set graphics mode to vfio
echo "Setting graphics mode to VFIO..."
asusctl graphics -m vfio

echo "Graphics mode set!"
sleep 1
